<?php

$mf = $_POST['mf'];


if ($mf <= 1.7) {
    echo "Média inferior ou igual a 1.7. Não poderá realizar o exame.";
} 
elseif ($mf >= 7.0) {
    echo "Média superior ou igual a 7.0. APROVADO.";
} 
else {

    $ne = (50 - ($mf * 6)) / 4;
    echo "Em exame. Nota necessária (NE): " . number_format($ne, 2);
}
?>